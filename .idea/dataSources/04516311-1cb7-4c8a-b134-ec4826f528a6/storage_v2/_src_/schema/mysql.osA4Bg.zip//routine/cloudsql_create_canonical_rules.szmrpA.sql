create
    definer = root@`127.0.0.1` procedure cloudsql_create_canonical_rules(IN in_rule_id bigint, IN user varchar(2048),
                                                                         IN db varchar(2048), IN obj varchar(2048),
                                                                         IN ops varchar(2048),
                                                                         IN in_op_result binary(1), OUT rc smallint,
                                                                         OUT errormsg text) security invoker
BEGIN
  DECLARE msg TEXT;
  DECLARE found_rows INT;
  DECLARE user_strend INT;
  DECLARE db_strend INT;
  DECLARE obj_strend INT;
  DECLARE ops_strend INT;
  DECLARE val_strend INT;
  DECLARE crules_cnt INT DEFAULT 0;
  DECLARE max_crules INT DEFAULT 1000;
  DECLARE total_crules INT DEFAULT 0;
  DECLARE ol_rule_id BIGINT;
  DECLARE user_pos INT DEFAULT 1;
  DECLARE db_pos INT DEFAULT 1;
  DECLARE obj_pos INT DEFAULT 1;
  DECLARE ops_pos INT DEFAULT 1;
  DECLARE val_pos INT DEFAULT 1;
  DECLARE v_userdef VARCHAR(64) DEFAULT '';
  DECLARE v_hostdef VARCHAR(64) DEFAULT '';
  DECLARE userstr VARCHAR(128);
  DECLARE dbstr VARCHAR(64);
  DECLARE objstr VARCHAR(64);
  DECLARE opstr VARCHAR(64);
  DECLARE val_str VARCHAR(64);
  DECLARE read_only_flag SMALLINT;
  DECLARE val_to_check VARCHAR(2048);
  DECLARE val_to_check1 VARCHAR(2048);
  DECLARE val VARCHAR(2048);
  DECLARE invalid_parameter VARCHAR(15);
  DECLARE loop_id INT DEFAULT 1;
  DECLARE t_id BIGINT DEFAULT 1;

  DECLARE max_crules_exceeded CONDITION FOR SQLSTATE 'AR999';
  DECLARE malformed_user CONDITION FOR SQLSTATE 'AR998';
  DECLARE empty_parameter CONDITION FOR SQLSTATE 'AR997';
  DECLARE invalid_op_name CONDITION FOR SQLSTATE 'AR996';
  DECLARE invalid_op_result CONDITION FOR SQLSTATE 'AR995';
  DECLARE read_only CONDITION FOR SQLSTATE 'AR994';
  DECLARE invalid_backtick CONDITION FOR SQLSTATE 'AR993';
  DECLARE invalid_wildcard CONDITION FOR SQLSTATE 'AR992';
  DECLARE invalid_character CONDITION FOR SQLSTATE 'AR991';

  -- Exit handler for when a duplicated canonical rules is found
  DECLARE EXIT HANDLER FOR 1062
  BEGIN
    GET DIAGNOSTICS CONDITION 1
    msg = MESSAGE_TEXT;

    SELECT rule_id INTO ol_rule_id
    FROM audit_log_rules_expanded
    WHERE (userdef,hostdef,dbname,object,operation,op_result) IN
    (SELECT userdef,hostdef,dbname,object,operation,op_result
    FROM temp_rules WHERE id = t_id);

    IF ol_rule_id = in_rule_id THEN
      SET errormsg = CONCAT('One or more values for user, database, object or operation are duplicated');
      SET rc = 6;
    ELSE
      SET errormsg = CONCAT('The audit rule provided overlaps with rule ',ol_rule_id);
      SET rc = 2;
    END IF;
    SELECT errormsg AS ERROR;
  END;

  -- Exit handler for invalid operation names
  DECLARE EXIT HANDLER FOR invalid_op_name
  BEGIN
    SET errormsg = CONCAT('The operation "',opstr,'" is not supported or invalid');
    SELECT errormsg AS ERROR;
    SET rc = 7;
  END;

  -- Exit handler for malformed user
  DECLARE EXIT HANDLER FOR malformed_user
  BEGIN
    SET errormsg = 'Malformed user account provided. The account should include a host definition';
    SELECT errormsg AS ERROR;
    SET rc = 5;
  END;

  -- Exit handler for when the max canonical rules are reached
  DECLARE EXIT HANDLER FOR max_crules_exceeded
  BEGIN
    SET errormsg = CONCAT('The audit rule will generate ', crules_cnt, ' combinations which exceed the limit of total ', max_crules, ' with existing ', total_crules, ' combinations');
    SELECT errormsg AS ERROR;
    SET rc = 3;
  END;

  -- Exit handler for empty / null parameters
  DECLARE EXIT HANDLER FOR empty_parameter
  BEGIN
    SET errormsg = 'One or more rule attributes are empty';
    SELECT errormsg AS ERROR;
    SET rc = 4;
  END;

  -- Exit handler for unexpected errors
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    GET DIAGNOSTICS CONDITION 1
    msg = MESSAGE_TEXT;
    SET errormsg = CONCAT('Unexpected error while updating a rule. The error returned by the server was: << ',msg,' >>');
    SELECT errormsg AS ERROR;
    SET rc = 1;
  END;

  -- Exit handler for invalid op_result
  DECLARE EXIT HANDLER FOR invalid_op_result
  BEGIN
    SET errormsg = "op_result should only be 'S'(successful), 'U'(unsuccessful) or 'B'(both)";
    SELECT errormsg as ERROR;
    set rc = 9;
  END;

  -- Exit handler for read_only database
  DECLARE EXIT HANDLER FOR read_only
  BEGIN
     SET errormsg = "The MySQL server is running with the --read-only option so it cannot execute this statement";
     SELECT errormsg as ERROR;
     set rc = 10;
  END;

  -- Exit handler for invalid backtick
  DECLARE EXIT HANDLER FOR invalid_backtick
  BEGIN
    SET errormsg = CONCAT('Invalid value for "', invalid_parameter,'" is provided. Backticks are only supported as both prefix and suffix but not in between two chars');
    SELECT errormsg AS ERROR;
    SET rc = 11;
  END;

  -- Exit handler for invalid wildcard
  DECLARE EXIT HANDLER FOR invalid_wildcard
  BEGIN
    SET errormsg = CONCAT('Invalid value for "', invalid_parameter,'" is provided. Wildcards are only supported as a prefix or suffix or both but not in between two chars');
    SELECT errormsg AS ERROR;
    SET rc = 12;
  END;

  -- Exit handler for invalid character
  DECLARE EXIT HANDLER FOR invalid_character
  BEGIN
    SET errormsg = CONCAT('Invalid value for "', invalid_parameter,'" is provided. Special characters are only supported between two backticks');
    SELECT errormsg AS ERROR;
    SET rc = 13;
  END;

  -- Check that op_result has valid value
  IF in_op_result IS NULL OR LENGTH(LTRIM(in_op_result)) = 0
    OR ( in_op_result <> 'S'
         AND in_op_result <> 'U'
         AND in_op_result <> 'B') THEN
     SIGNAL SQLSTATE 'AR995';
  END IF;

  SET rc = 1;

  -- Check that none of the parameters are empty
  IF LENGTH(TRIM(user)) = 0
    OR LENGTH(TRIM(db)) = 0
    OR LENGTH(TRIM(obj)) = 0
    OR LENGTH(TRIM(ops)) = 0 THEN
    SIGNAL SQLSTATE 'AR997';
  END IF;

  -- Check if the DB is running in read_only mode
  select @@GLOBAL.read_only into read_only_flag;
  IF read_only_flag = 1 THEN
    SIGNAL SQLSTATE 'AR994';
  END IF;

  SET user_strend = LOCATE(',',user, user_pos);
  SET db_strend = LOCATE(',',db, db_pos);
  SET obj_strend = LOCATE(',',obj, obj_pos);
  SET ops_strend = LOCATE(',',ops, ops_pos);

  WHILE user_pos <= LENGTH(user) OR user_strend != 0 DO
    -- If user_strend is zero then either there was no , or we hit the last
    -- value of the CSV
    IF user_strend = 0 THEN
      SET user_strend = LENGTH(user) + 1;
    END IF;
    SET userstr = SUBSTR(user FROM user_pos FOR user_strend - user_pos);
    -- Extract host definition from the user account
    IF userstr = '*' THEN
      SET v_userdef = '*';
      SET v_hostdef = '*';
    END IF;
    WHILE db_pos <= LENGTH(db) OR db_strend != 0 DO
      IF db_strend = 0 THEN
        SET db_strend = LENGTH(db) + 1;
      END IF;
      WHILE obj_pos <= LENGTH(obj) OR obj_strend != 0 DO
        IF obj_strend = 0 THEN
          SET obj_strend = LENGTH(obj) + 1;
        END IF;
        WHILE ops_pos <= LENGTH(ops) OR ops_strend != 0 DO
          IF ops_strend = 0 THEN
            SET ops_strend = LENGTH(ops) + 1;
          END IF;

          -- Check that none of the parameters are empty
          SET dbstr = TRIM(SUBSTR(db FROM db_pos FOR db_strend - db_pos));
          SET objstr = TRIM(SUBSTR(obj FROM obj_pos FOR obj_strend - obj_pos));
          SET opstr = LOWER(TRIM(SUBSTR(ops FROM ops_pos FOR ops_strend - ops_pos)));
          IF LENGTH(dbstr) = 0
            OR LENGTH(objstr) = 0
            OR LENGTH(opstr) = 0 THEN
              SIGNAL SQLSTATE 'AR997';
          END IF;

          SET loop_id = 1;
          SET val_to_check1 = '';
          -- Check backtick and wildcard
          check_backtick_wildcard: LOOP
          -- We iterate thru loop for each parameter value (user, host, db, object)
          -- separately and assign that relevant value to val_to_check variable
          -- which is later checked for backticks, wildcards and commas
            CASE loop_id
              WHEN 1 THEN  -- Assign user value to val_to_check
                IF (LOCATE('@', userstr) > 0) THEN
                  SET v_userdef = TRIM(SUBSTRING_INDEX(userstr,'@',1));
                  SET v_hostdef = LOWER(TRIM(SUBSTRING_INDEX(userstr,'@',-1)));
                ELSE
                  SET v_userdef = userstr;
                END IF;
                IF LENGTH(v_userdef) = 0
                  OR STRCMP(v_userdef, '`') = 0
                  OR STRCMP(v_hostdef, '`') = 0 THEN
                    SIGNAL SQLSTATE 'AR997';
                END IF;
                SET val_to_check = v_userdef;
                SET val = user;
                SET val_strend = user_strend;
                SET invalid_parameter = 'user';
              WHEN 2 THEN  -- Assign host value to val_to_check
                IF (LOCATE('@', userstr) > 0) THEN
                  SET v_hostdef = LOWER(TRIM(SUBSTRING_INDEX(userstr,'@',-1)));
                ELSE
                  SET v_hostdef = userstr;
                END IF;
                SET val_to_check = v_hostdef;
                SET val = user;
                SET val_strend = user_strend;
                SET invalid_parameter = 'host';
              WHEN 3 THEN  -- Assign db value to val_to_check
                SET val_to_check = dbstr;
                SET val = db;
                SET val_strend = db_strend;
                SET invalid_parameter = 'db';
              WHEN 4 THEN  -- Assign object value to val_to_check
                SET val_to_check = objstr;
                SET val = obj;
                SET val_strend = obj_strend;
                SET invalid_parameter = 'object';
            END CASE;

            -- Check if comma is provided between two backticks
            IF (LOCATE('`', REVERSE(val_to_check)) = 1) THEN
              SET val_to_check1 = CONCAT(val_to_check1, val_to_check);
              SET val_to_check = val_to_check1;
              SET val_to_check1 = '';

              -- Once commas between backticks are parsed successfully,
              -- assign val_to_check back to original parameter value
              CASE loop_id
                WHEN 1 THEN  -- Assign val_to_check to user value
                  SET v_userdef = val_to_check;
                  IF (LENGTH(v_hostdef) = 0) THEN
                    SIGNAL SQLSTATE 'AR998';
                  END IF;
                WHEN 2 THEN  -- Assign val_to_check to host value
                  SET v_hostdef = val_to_check;
                WHEN 3 THEN  -- Assign val_to_check to db value
                  SET dbstr = val_to_check;
                WHEN 4 THEN  -- Assign val_to_check to object value
                  SET objstr = val_to_check;
              END CASE;
            ELSE
              IF (LENGTH(val_to_check1) = 0 AND LOCATE('`', val_to_check) = 1) THEN
                SET val_to_check1 = CONCAT(val_to_check, ',');
              ELSE
                IF (LENGTH(val_to_check1) > 0) THEN
                  SET val_to_check1 = CONCAT(val_to_check1, val_to_check, ',');
                END IF;
              END IF;
              IF (LENGTH(val_to_check1) > 0) THEN
                SET val_pos = val_strend + 1;
                SET val_strend = LOCATE(',', val, val_pos);
                IF val_strend = 0 THEN
                  SET val_strend = LENGTH(val) + 1;
                END IF;
                SET val_str = TRIM(SUBSTR(val FROM val_pos FOR val_strend - val_pos));

                -- Assign next comma separated value within backticks
                -- to appropriate parameter and continue with loop for same parameter
                IF (LENGTH(val_str) > 0) THEN
                  CASE loop_id
                    WHEN 1 THEN  -- Assign val_str to user value
                      SET userstr = val_str;
                      SET user_strend = val_strend;
                    WHEN 2 THEN  -- Assign val_str to user value
                      SET userstr = val_str;
                      SET user_strend = val_strend;
                    WHEN 3 THEN  -- Assign val_str to db value
                      SET dbstr = val_str;
                      SET db_strend = val_strend;
                    WHEN 4 THEN  -- Assign val_str to object value
                      SET objstr = val_str;
                      SET obj_strend = val_strend;
                  END CASE;

                  ITERATE check_backtick_wildcard;
                END IF;
              END IF;
            END IF;

            IF (loop_id = 1 AND LENGTH(v_hostdef) = 0) THEN
              SIGNAL SQLSTATE 'AR998';
            END IF;
            IF (LENGTH(val_to_check1) > 0) THEN
              SET val_to_check = val_to_check1;
              SET val_to_check1 = '';
            END IF;

            -- backtick should only appear as both prefix and suffix
            IF (LOCATE('``', val_to_check) = 1) THEN
              SIGNAL SQLSTATE 'AR993';
            ELSEIF (LOCATE('`', val_to_check) = 1) THEN
              IF (LOCATE('`', val_to_check, 2) < LENGTH(val_to_check)) THEN
                SIGNAL SQLSTATE 'AR993';
              END IF;
            ELSE
              IF (LOCATE('`', val_to_check, 2) > 1) THEN
                SIGNAL SQLSTATE 'AR993';
              ELSE  -- wildcard should only appear as prefix or suffix or both
                -- Replace % in hostname with *
                IF (loop_id = 2) THEN
                  SET v_hostdef = REPLACE(v_hostdef, '%', '*');
                  SET val_to_check = v_hostdef;
                END IF;
                IF ((LOCATE('*', val_to_check) = 1) OR
                   (LOCATE('*', val_to_check) = LENGTH(val_to_check))) THEN
                  IF (LOCATE('*', val_to_check, 2) BETWEEN 2 and LENGTH(val_to_check)-1) THEN
                    SIGNAL SQLSTATE 'AR992';
                  END IF;
                ELSEIF (LOCATE('*', val_to_check) BETWEEN 2 and LENGTH(val_to_check)-1) THEN
                  SIGNAL SQLSTATE 'AR992';
                END IF;
                -- special characters should not appear w/o backticks
                IF (loop_id = 2) THEN
                  -- host name and IP can have . and - with * as wildcard
                  IF (val_to_check REGEXP '[^A-Za-z0-9*.-]') THEN
                    SIGNAL SQLSTATE 'AR991';
                  END IF;
                ELSE
                  -- user, db and object names can have _ with * as wildcard
                  IF (val_to_check REGEXP '[^A-Za-z0-9_*]') THEN
                    SIGNAL SQLSTATE 'AR991';
                  END IF;
                END IF;
              END IF;
            END IF;

            SET loop_id = loop_id + 1;
            IF loop_id < 5 THEN
              ITERATE check_backtick_wildcard;
            END IF;

            LEAVE check_backtick_wildcard;
          END LOOP check_backtick_wildcard;

          -- Check that the operation is a valid one
          SELECT count(*) INTO found_rows FROM mysql.audit_log_supported_ops WHERE op_name = opstr;
          IF found_rows = 0 AND opstr <> "*" THEN
            SIGNAL SQLSTATE 'AR996';
          END IF;

          INSERT INTO temp_rules
          (id,rule_id,userdef,hostdef,dbname,object,operation,op_result,modified)
          VALUES
            (crules_cnt+1,
            in_rule_id,
            v_userdef,
            v_hostdef,
            dbstr,
            objstr,
            opstr,
            in_op_result,
            1);
          SET crules_cnt = crules_cnt + 1;
          SET ops_pos = ops_strend + 1;
          SET ops_strend = LOCATE(',',ops, ops_pos);
        END WHILE;
        SET ops_pos = 1;
        SET ops_strend = LOCATE(',',ops, ops_pos);
        SET obj_pos = obj_strend + 1;
        SET obj_strend = LOCATE(',',obj, obj_pos);
      END WHILE;
      SET obj_pos = 1;
      SET obj_strend = LOCATE(',',obj, obj_pos);
      SET db_pos = db_strend + 1;
      SET db_strend = LOCATE(',',db, db_pos);
    END WHILE;
    SET db_pos = 1;
    SET db_strend = LOCATE(',',db, db_pos);
    SET user_pos = user_strend + 1;
    SET user_strend = LOCATE(',',user, user_pos);
    SET v_userdef = '';
    SET v_hostdef = '';
  END WHILE;

  -- Get total no. of existing expanded rules
  SELECT count(*) INTO total_crules
  FROM audit_log_rules_expanded
  FOR UPDATE;

  -- Check if total and no. of rules being added exceed max_crules
  IF (crules_cnt + total_crules) > max_crules THEN
    SIGNAL SQLSTATE 'AR999';
  ELSE
    -- We are inserting records in the loop back to audit_log_rules_expanded
    -- to prevent gaps in auto_increment value of ID col. by bulk inserts
    -- and to handle exception 1062
    WHILE (t_id <= crules_cnt) DO
      INSERT INTO audit_log_rules_expanded
      (rule_id,userdef,hostdef,dbname,object,operation,op_result,modified)
      SELECT rule_id,userdef,hostdef,dbname,object,operation,op_result,modified
      FROM temp_rules WHERE id = t_id;
      SET t_id = t_id + 1;
    END WHILE;
  END IF;

  SET rc = 0;
END;

grant select on user to 'mysql.session'@localhost;

