create
    definer = root@localhost procedure addSecondaryIdxOnReplica(IN idxType varchar(20), IN idxName varchar(100),
                                                                IN tableName varchar(100),
                                                                IN idxDefinition varchar(500),
                                                                IN idxOption varchar(255))
BEGIN

    DECLARE v_newIdxCount INT DEFAULT 0;
    DECLARE v_registerIdx INT DEFAULT 0;
    DECLARE v_oldSqlLogBin INT DEFAULT 0;
    DECLARE v_dbName VARCHAR(64) DEFAULT '';
    DECLARE v_tableName VARCHAR(64) DEFAULT '';

    DECLARE exit HANDLER FOR SQLEXCEPTION, SQLSTATE '45000'
    BEGIN
        SET sql_log_bin = v_oldSqlLogBin;
        RESIGNAL;
    END;

    SET v_oldSqlLogBin = (SELECT @@sql_log_bin);
    SET sql_log_bin = 0;

    IF LOCATE('#', idxType) > 0 OR LOCATE('--', idxType) > 0 OR LOCATE('/*', idxType) > 0
    THEN
       SIGNAL SQLSTATE '45000'
       SET MESSAGE_TEXT = 'Suspicious input parameter with sql comment sequence';
    END IF;

    IF LOCATE('.', tableName) > 0 THEN
      SET v_dbName = SUBSTRING_INDEX(tableName, '.', 1);
      SET v_tableName = SUBSTRING_INDEX(tableName, '.', -1);
    ELSE
      SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Please provide database name along with table name: db.table';
    END IF;

    IF v_dbName = 'mysql' THEN
       SIGNAL SQLSTATE '45000'
          SET MESSAGE_TEXT = 'Invalid database name: mysql. Please provide database name along with table name: db.table';
    END IF;

    SET @addSecondaryIdx_sql = CONCAT('CREATE ', idxType, ' INDEX ', idxName, ' ON ', v_dbName, '.', v_tableName, ' ( ', idxDefinition, ' ) ', idxOption);

    SELECT @addSecondaryIdx_sql AS 'Step 1';
    PREPARE idx_stmt FROM @addSecondaryIdx_sql;
    EXECUTE idx_stmt;
    DEALLOCATE PREPARE idx_stmt;

    SELECT table_schema, table_name, non_unique, index_schema, index_name, seq_in_index,
    column_name, collation, cardinality, index_type, comment, index_comment
    FROM information_schema.statistics
    WHERE table_schema = v_dbName
    AND table_name = v_tableName
    AND index_name = idxName;

    SELECT 'Insert record into mysql.cloudsql_replica_index' AS 'Step 2';
    INSERT INTO mysql.cloudsql_replica_index
      (db_name, table_name, index_name)
    VALUES
      (v_dbName, v_tableName, idxName);

    SELECT * FROM mysql.cloudsql_replica_index WHERE db_name = v_dbName AND table_name = v_tableName AND index_name = idxName;

    SET sql_log_bin = v_oldSqlLogBin;

   END;

