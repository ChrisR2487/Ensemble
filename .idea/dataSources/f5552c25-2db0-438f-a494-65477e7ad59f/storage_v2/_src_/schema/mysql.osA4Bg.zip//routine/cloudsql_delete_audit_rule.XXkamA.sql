create
    definer = root@`127.0.0.1` procedure cloudsql_delete_audit_rule(IN rule_id_list varchar(2048), IN reload_mode int,
                                                                    OUT rc smallint, OUT errormsg text)
BEGIN
  DECLARE msg TEXT;
  DECLARE ruleid_strend INT;
  DECLARE ruleid_pos INT DEFAULT 1;
  DECLARE rule_to_delete BIGINT;
  DECLARE read_only_flag SMALLINT;

  DECLARE empty_parameter CONDITION FOR SQLSTATE 'AR997';
	DECLARE read_only CONDITION FOR SQLSTATE 'AR994';

  -- Exit handler for empty / null parameters
  DECLARE EXIT HANDLER FOR empty_parameter
  BEGIN
    SET errormsg = 'One or more rule attributes are empty';
    SELECT errormsg AS ERROR;
    SET rc = 4;
    ROLLBACK;
  END;

  -- Exit handler for unexpected errors
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    GET DIAGNOSTICS CONDITION 1
    msg = MESSAGE_TEXT;
    SET errormsg = CONCAT('Unexpected error while deleting a rule. The error returned by the server was: << ',msg,' >>');
    SELECT errormsg AS ERROR;
    SET rc = 1;
    ROLLBACK;
  END;

	-- Exit handler for read_only database
  DECLARE EXIT HANDLER FOR read_only
  BEGIN
     SET errormsg = "The MySQL server is running with the --read-only option so it cannot execute this statement";
     SELECT errormsg as ERROR;
     set rc = 10;
     ROLLBACK;
  END;

  -- Check that none of the parameters are empty or null
  SET rc = 1;
  IF rule_id_list IS NULL OR LENGTH(TRIM(rule_id_list)) = 0 THEN
        SIGNAL SQLSTATE 'AR997';
  END IF;
  SET ruleid_strend = LOCATE(',',rule_id_list, ruleid_pos);

  -- Check if the DB is running in read_only mode
  select @@GLOBAL.read_only into read_only_flag;
  IF read_only_flag = 1 THEN
     SIGNAL SQLSTATE 'AR994';
  END IF;

  START TRANSACTION;
    WHILE ruleid_pos <= LENGTH(rule_id_list) OR ruleid_strend != 0 DO
      IF ruleid_strend = 0 THEN
        SET ruleid_strend = LENGTH(rule_id_list)+1;
      END IF;
      SET rule_to_delete = SUBSTR(rule_id_list FROM ruleid_pos FOR ruleid_strend - ruleid_pos);

      -- Delete corresponding canonical rules
      DELETE FROM mysql.audit_log_rules_expanded WHERE rule_id = rule_to_delete;

      -- Delete user-facing rule
      DELETE FROM mysql.audit_log_rules WHERE id = rule_to_delete;

      SET ruleid_pos = ruleid_strend+1;
      SET ruleid_strend = LOCATE(',',rule_id_list, ruleid_pos);
    END WHILE;
  COMMIT;
  SET rc = 0;
	CALL mysql.cloudsql_reload_audit_rule(reload_mode);
END;

