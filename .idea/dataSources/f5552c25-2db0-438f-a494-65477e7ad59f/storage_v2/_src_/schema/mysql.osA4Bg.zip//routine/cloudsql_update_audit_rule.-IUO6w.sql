create
    definer = root@`127.0.0.1` procedure cloudsql_update_audit_rule(IN in_rule_id bigint, IN user varchar(2048),
                                                                    IN db varchar(2048), IN obj varchar(2048),
                                                                    IN ops varchar(2048), IN in_op_result binary(1),
                                                                    IN reload_mode int, OUT rc smallint,
                                                                    OUT errormsg text)
BEGIN
  DECLARE msg TEXT;
  DECLARE found_rows INT;
  DECLARE new_rule_id BIGINT;
  DECLARE ol_rule_id BIGINT;
  DECLARE v_userdef VARCHAR(64);
  DECLARE v_hostdef VARCHAR(64);
	DECLARE read_only_flag SMALLINT;
  DECLARE autocommit_flag SMALLINT;
  DECLARE cur_user_list VARCHAR(2048);
  DECLARE cur_db_list VARCHAR(2048);
  DECLARE cur_obj_list VARCHAR(2048);
  DECLARE cur_ops_list VARCHAR(2048);
  DECLARE cur_opres ENUM('S','U','B');
  DECLARE session_isolation_level VARCHAR(25);

  DECLARE invalid_op_result CONDITION FOR SQLSTATE 'AR998';
  DECLARE empty_parameter CONDITION FOR SQLSTATE 'AR997';
  DECLARE rule_not_found CONDITION FOR SQLSTATE 'AR995';
  DECLARE read_only CONDITION FOR SQLSTATE 'AR994';

  -- Exit handler for invalid op_result
  DECLARE EXIT HANDLER FOR invalid_op_result
  BEGIN
    SET errormsg = "op_result should only be 'S'(successful), 'U'(unsuccessful) or 'B'(both)";
    SELECT errormsg as ERROR;
    set rc = 9;
    ROLLBACK;
  END;

  -- Exit handler for empty / null parameters
  DECLARE EXIT HANDLER FOR empty_parameter
  BEGIN
    SET errormsg = 'One or more rule attributes are empty. To keep the existing value specify NULL instead';
    SELECT errormsg AS ERROR;
    SET rc = 4;
    ROLLBACK;
  END;

  -- Exit handler for unexpected errors
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    GET DIAGNOSTICS CONDITION 1
    msg = MESSAGE_TEXT;
    SET errormsg = concat('Unexpected error while updating a rule. The error returned by the server was: << ',msg,' >>');
    SELECT errormsg AS ERROR;
    SET rc = 1;
    ROLLBACK;
  END;

  -- Exit handler for when the rule id provided was not found
  DECLARE EXIT HANDLER FOR rule_not_found
  BEGIN
    SET errormsg = 'The rule id provided was not found';
    SELECT errormsg AS ERROR;
    SET rc = 8;
    ROLLBACK;
  END;

	-- Exit handler for read_only database
  DECLARE EXIT HANDLER FOR read_only
  BEGIN
     SET errormsg = "The MySQL server is running with the --read-only option so it cannot execute this statement";
     SELECT errormsg as ERROR;
     set rc = 10;
     ROLLBACK;
  END;

  SET rc = 1;

  -- Check that none of the parameters are empty
  IF LENGTH(trim(user)) = 0
    OR LENGTH(trim(db)) = 0
    OR LENGTH(trim(obj)) = 0
    OR LENGTH(trim(ops)) = 0 THEN
    SIGNAL SQLSTATE 'AR997';
  END IF;

  -- Check that op_result has valid value
  IF in_op_result IS NOT NULL
    AND in_op_result <> 'S'
    AND in_op_result <> 'U'
    AND in_op_result <> 'B' THEN
     SIGNAL SQLSTATE 'AR998';
  END IF;

  -- Check if the DB is running in read_only mode
  select @@GLOBAL.read_only into read_only_flag;
  IF read_only_flag = 1 THEN
     SIGNAL SQLSTATE 'AR994';
  END IF;

  SELECT @@SESSION.autocommit INTO autocommit_flag;
  -- Enable autocommit to allow temp table with enforce_gtid_consistency
  SET autocommit = 1;

  -- Create temp table to insert all rule combinations before inserting them to expanded table
  -- to prevent rolling back records on error
  CREATE TEMPORARY TABLE temp_rules
  SELECT * FROM audit_log_rules_expanded LIMIT 0;

  -- Get current isolation level
  SELECT @@SESSION.transaction_isolation INTO session_isolation_level;

  START TRANSACTION;
  -- Set isolation level to read committed so that we can read
  -- committed transactions from another session
  SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;

  -- If the rule does not exist, abort (FOUND_ROWS is deprecated, so using COUNT() instead)
  SELECT count(*) INTO found_rows FROM mysql.audit_log_rules WHERE id = in_rule_id;
  IF found_rows = 0 THEN
    SIGNAL SQLSTATE 'AR995';
  END IF;

  -- Retrieve the rule to be updated
  SELECT
    username,dbname,object,operation,op_result
  INTO
    cur_user_list,cur_db_list,cur_obj_list,cur_ops_list,cur_opres
  FROM
    mysql.audit_log_rules
  WHERE
    id = in_rule_id;

  -- Delete corresponding canonical rules
  DELETE FROM mysql.audit_log_rules_expanded WHERE rule_id = in_rule_id;

  -- Update existing rule with non-null parameters
  UPDATE mysql.audit_log_rules
  SET
      username = IFNULL(user,username),
      dbname = IFNULL(db,dbname),
      object = IFNULL(obj,object),
      operation = IFNULL(ops,operation),
      op_result = IFNULL(in_op_result,op_result)
  WHERE id = in_rule_id;

  SET new_rule_id = in_rule_id;

  -- We need to replace any null parameters with the current values
  IF(user IS NULL) THEN
    SET user = cur_user_list;
  END IF;
  IF(db IS NULL) THEN
    SET db = cur_db_list;
  END IF;
  IF(obj IS NULL) THEN
    SET obj = cur_obj_list;
  END IF;
  IF(ops IS NULL) THEN
    SET ops = cur_ops_list;
  END IF;
  IF(in_op_result IS NULL) THEN
    SET in_op_result = cur_opres;
  END IF;

  -- Create canonical rules by calling the common SP
  CALL mysql.cloudsql_create_canonical_rules(new_rule_id,user,db,obj,ops,in_op_result,rc,errormsg);

  -- If any errors while creating the canonical rules, we rollback all changes
  IF rc <> 0 THEN
    ROLLBACK;
  ELSE
    COMMIT;
    SET rc = 0;
		CALL mysql.cloudsql_reload_audit_rule(reload_mode);
  END IF;

  -- Drop temp table
  DROP TEMPORARY TABLE IF EXISTS temp_rules;

  -- Set isolation level back to default value
  SET @@SESSION.transaction_isolation = session_isolation_level;
END;

grant select on user to 'mysql.session'@localhost;

