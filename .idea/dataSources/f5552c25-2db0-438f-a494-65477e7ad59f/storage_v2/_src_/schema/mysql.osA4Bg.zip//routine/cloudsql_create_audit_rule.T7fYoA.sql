create
    definer = root@`127.0.0.1` procedure cloudsql_create_audit_rule(IN user varchar(2048), IN db varchar(2048),
                                                                    IN obj varchar(2048), IN ops varchar(2048),
                                                                    IN op_result binary(1), IN reload_mode int,
                                                                    OUT rc smallint, OUT errormsg text)
BEGIN
  DECLARE msg TEXT;
  DECLARE v_userdef VARCHAR(64);
  DECLARE v_hostdef VARCHAR(64);
  DECLARE new_rule_id BIGINT;
  DECLARE read_only_flag SMALLINT;
	DECLARE autocommit_flag SMALLINT;
  DECLARE session_isolation_level VARCHAR(25);

  DECLARE read_only CONDITION FOR SQLSTATE 'AR994';
  DECLARE empty_parameter CONDITION FOR SQLSTATE 'AR997';
  DECLARE invalid_op_result CONDITION FOR SQLSTATE 'AR998';

  -- Exit handler for empty / null parameters
  DECLARE EXIT HANDLER FOR empty_parameter
  BEGIN
    SET errormsg = 'One or more rule attributes are empty';
    SELECT errormsg AS ERROR;
    SET rc = 4;
    ROLLBACK;
  END;

  -- Exit handler for invalid op_result
  DECLARE EXIT HANDLER FOR invalid_op_result
  BEGIN
    SET errormsg = "op_result should only be 'S'(successful), 'U'(unsuccessful) or 'B'(both)";
    SELECT errormsg as ERROR;
    set rc = 9;
    ROLLBACK;
  END;

  -- Exit handler for unexpected errors
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    GET DIAGNOSTICS CONDITION 1
    msg = MESSAGE_TEXT;
    SET errormsg = CONCAT('Unexpected error while creating the rule. The error returned by the server was: << ',msg,' >>');
    SELECT errormsg AS ERROR;
    SET rc = 1;
    ROLLBACK;
  END;

  -- Exit handler for read_only database
  DECLARE EXIT HANDLER FOR read_only
  BEGIN
     SET errormsg = "The MySQL server is running with the --read-only option so it cannot execute this statement";
     SELECT errormsg as ERROR;
     set rc = 10;
     ROLLBACK;
  END;

  -- Check that none of the parameters are empty or null
  IF user IS NULL OR LENGTH(TRIM(user)) = 0
    OR db IS NULL OR LENGTH(TRIM(db)) = 0
    OR obj IS NULL OR LENGTH(TRIM(obj)) = 0
    OR ops IS NULL OR LENGTH(TRIM(ops)) = 0 THEN
    SIGNAL SQLSTATE 'AR997';
  END IF;

  -- Check that op_result has valid value
  IF op_result IS NULL OR LENGTH(LTRIM(op_result)) = 0
    OR ( op_result <> 'S'
         AND op_result <> 'U'
         AND op_result <> 'B') THEN
     SIGNAL SQLSTATE 'AR998';
  END IF;

	-- Check if the DB is running in read_only mode
	select @@GLOBAL.read_only into read_only_flag;
	IF read_only_flag = 1 THEN
		 SIGNAL SQLSTATE 'AR994';
	END IF;

  SET rc = 1;

  -- Get current autocommit value
  SELECT @@SESSION.autocommit INTO autocommit_flag;
  -- Enable autocommit to allow temp table with enforce_gtid_consistency
  SET autocommit = 1;

  -- Create temp table to insert all rule combinations before inserting them to expanded table
  -- to prevent rolling back records on error
  CREATE TEMPORARY TABLE temp_rules
  SELECT * FROM audit_log_rules_expanded LIMIT 0;
  -- Get current isolation level
  SELECT @@SESSION.transaction_isolation INTO session_isolation_level;

  START TRANSACTION;
  -- Set isolation level to read committed so that we can read
  -- committed transactions from another session
  SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;

  -- Insert the rule in the user-facing table
  INSERT INTO mysql.audit_log_rules (username,dbname,object,operation,op_result)
  VALUES (user,db,obj,ops,op_result);

  SET new_rule_id = last_insert_id();

  -- Create canonical rules by calling the common SP
  CALL mysql.cloudsql_create_canonical_rules(new_rule_id,user,db,obj,ops,op_result,rc,errormsg);

  -- If any errors while creating the canonical rules, we rollback all changes
  IF rc <> 0 THEN
    ROLLBACK;
  ELSE
    COMMIT;
    SET rc = 0;
		CALL mysql.cloudsql_reload_audit_rule(reload_mode);
  END IF;

  -- Drop temp table
  DROP TEMPORARY TABLE IF EXISTS temp_rules;

  -- Set isolation level back to default value
  SET @@SESSION.transaction_isolation = session_isolation_level;
END;

grant select on user to 'mysql.session'@localhost;

