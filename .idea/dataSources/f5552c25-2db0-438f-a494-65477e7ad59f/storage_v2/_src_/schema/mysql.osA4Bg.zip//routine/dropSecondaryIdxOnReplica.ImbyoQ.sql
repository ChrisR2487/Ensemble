create
    definer = root@localhost procedure dropSecondaryIdxOnReplica(IN idxName varchar(100), IN tableName varchar(100),
                                                                 IN idxOption varchar(255))
BEGIN

    DECLARE v_oldSqlLogBin INT;
    DECLARE v_dbName VARCHAR(64) DEFAULT NULL;
    DECLARE v_tableName VARCHAR(64) DEFAULT NULL;
    DECLARE v_removeIdx INT DEFAULT 0;

    DECLARE exit HANDLER FOR SQLEXCEPTION, SQLSTATE '45000'
    BEGIN
        SET sql_log_bin = v_oldSqlLogBin;
        RESIGNAL;
    END;

    SET v_oldSqlLogBin = (SELECT @@sql_log_bin);
    SET sql_log_bin = 0;

    IF LOCATE('.', tableName) > 0 THEN
      SET v_dbName = SUBSTRING_INDEX(tableName, '.', 1);
      SET v_tableName = SUBSTRING_INDEX(tableName, '.', -1);
    ELSE
      SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Please provide database name along with table name: db.table';
    END IF;

    SELECT 'Delete record from mysql.cloudsql_replica_index' AS 'Step 1';
    DELETE FROM mysql.cloudsql_replica_index
    WHERE db_name = v_dbName
    AND table_name = v_tableName
    AND index_name = idxName;

    SELECT ROW_COUNT() INTO v_removeIdx;
    IF v_removeIdx = 0 THEN
      SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Failed to find the index in mysql.cloudsql_replica_index table. The index is not dropped.';
    END IF;

    SET @dropSecondaryIdx_sql = CONCAT('DROP INDEX ', idxName, ' ON ', v_dbName, '.', v_tableName, ' ', idxOption);
    SELECT @dropSecondaryIdx_sql  AS 'Step 2';
    PREPARE drop_idx_stmt FROM @dropSecondaryIdx_sql;
    EXECUTE drop_idx_stmt;
    DEALLOCATE PREPARE drop_idx_stmt;

    SET sql_log_bin = v_oldSqlLogBin;

   END;

