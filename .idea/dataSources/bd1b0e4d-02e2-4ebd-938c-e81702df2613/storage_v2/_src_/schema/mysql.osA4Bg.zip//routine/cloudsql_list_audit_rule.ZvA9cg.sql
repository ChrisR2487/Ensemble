create
    definer = root@`127.0.0.1` procedure cloudsql_list_audit_rule(IN rule_id_list varchar(2048), OUT rc smallint, OUT errormsg text)
BEGIN
  DECLARE msg TEXT;

  DECLARE empty_parameter CONDITION FOR SQLSTATE 'AR997';

  -- Exit handler for empty / null parameters
  DECLARE EXIT HANDLER FOR empty_parameter
  BEGIN
    SET errormsg = 'One or more rule attributes are empty';
    SELECT errormsg AS ERROR;
    SET rc = 4;
  END;

  -- Exit handler for unexpected errors
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    GET DIAGNOSTICS CONDITION 1
    msg = MESSAGE_TEXT;
    SET errormsg = CONCAT('Unexpected error while reading the rule. The error returned by the server was: << ',msg,' >>');
    SELECT errormsg AS ERROR;
    SET rc = 1;
  END;

  SET rc = 1;
  -- Check that none of the parameters are empty or null
  IF rule_id_list IS NULL OR LENGTH(TRIM(rule_id_list)) = 0 THEN
     SIGNAL SQLSTATE 'AR997';
  END IF;

  IF FIND_IN_SET('*', rule_id_list) <> 0 THEN
      -- Return all rules
    SELECT
      id,
      username,
      dbname,
      object,
      operation,
      op_result
    FROM
      mysql.audit_log_rules;
  ELSE
    SELECT
      id,
      username,
      dbname,
      object,
      operation,
      op_result
    FROM
      mysql.audit_log_rules
    WHERE
      FIND_IN_SET(id, rule_id_list) <> 0;
  END IF;
  SET rc = 0;
END;

